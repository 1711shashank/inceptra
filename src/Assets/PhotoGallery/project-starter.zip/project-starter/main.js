const canvas = document.querySelector("#canvas");
//code here
